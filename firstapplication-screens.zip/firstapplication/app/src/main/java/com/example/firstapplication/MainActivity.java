package com.example.firstapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/** Landing screen: shows the main modules of the project in a grid of cards. */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View.OnClickListener moduleClick = v -> {
            String module;
            int id = v.getId();
            if (id == R.id.cardCourses) module = getString(R.string.module_courses);
            else if (id == R.id.cardTasks) module = getString(R.string.module_tasks);
            else if (id == R.id.cardNotes) module = getString(R.string.module_notes);
            else if (id == R.id.cardChat) module = getString(R.string.module_chat);
            else if (id == R.id.cardSettings) module = getString(R.string.module_settings);
            else module = getString(R.string.module_about);
            Toast.makeText(this, module + " clicked", Toast.LENGTH_SHORT).show();
        };

        findViewById(R.id.cardCourses).setOnClickListener(moduleClick);
        findViewById(R.id.cardTasks).setOnClickListener(moduleClick);
        findViewById(R.id.cardNotes).setOnClickListener(moduleClick);
        findViewById(R.id.cardChat).setOnClickListener(moduleClick);
        findViewById(R.id.cardSettings).setOnClickListener(moduleClick);
        findViewById(R.id.cardAbout).setOnClickListener(moduleClick);

        findViewById(R.id.btnOpenProfile).setOnClickListener(v -> {
            Intent intent = new Intent(this, ProfileActivity.class);
            String email = getIntent().getStringExtra("email");
            if (email != null) {
                intent.putExtra("email", email);
                intent.putExtra("name", email.split("@")[0]);
            }
            startActivity(intent);
        });
    }
}
