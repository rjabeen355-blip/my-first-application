package com.example.firstapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        EditText etName = findViewById(R.id.etName);
        EditText etEmail = findViewById(R.id.etRegEmail);
        EditText etPhone = findViewById(R.id.etPhone);
        EditText etPassword = findViewById(R.id.etRegPassword);
        EditText etConfirm = findViewById(R.id.etRegConfirm);
        RadioGroup rgGender = findViewById(R.id.rgGender);
        CheckBox cbTerms = findViewById(R.id.cbTerms);
        Button btnRegister = findViewById(R.id.btnRegister);
        TextView tvGoLogin = findViewById(R.id.tvGoLogin);

        btnRegister.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String phone = etPhone.getText().toString().trim();
            String password = etPassword.getText().toString();
            String confirm = etConfirm.getText().toString();

            if (name.isEmpty()) {
                etName.setError(getString(R.string.err_required));
                return;
            }
            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                etEmail.setError(getString(R.string.err_email));
                return;
            }
            if (phone.isEmpty()) {
                etPhone.setError(getString(R.string.err_required));
                return;
            }
            if (password.length() < 6) {
                etPassword.setError(getString(R.string.err_password));
                return;
            }
            if (!password.equals(confirm)) {
                etConfirm.setError(getString(R.string.err_match));
                return;
            }
            if (!cbTerms.isChecked()) {
                Toast.makeText(this, R.string.err_terms, Toast.LENGTH_SHORT).show();
                return;
            }

            boolean isMale = rgGender.getCheckedRadioButtonId() == R.id.rbMale;

            Intent intent = new Intent(this, ProfileActivity.class);
            intent.putExtra("name", name);
            intent.putExtra("email", email);
            intent.putExtra("phone", phone);
            intent.putExtra("gender", isMale ? "Male" : "Female");
            startActivity(intent);
            finish();
        });

        tvGoLogin.setOnClickListener(v -> finish());
    }
}
